/*
Program: 05_comments.c
Author: Harry
Date: 3 October 2030
*/
#include<stdio.h>

int main(){
    
    // I am writing this just for fun. This line doesnt do anything
    printf("Hello World");
    // Return 0 is returning 0 to the OS
    return 0; // This is return 
}